import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: { colors: { ink: "#11110f", panel: "#1a1a17", gold: "#d6ad58", muted: "#92918a" }, boxShadow: { glow: "0 0 50px rgba(214,173,88,.10)" } } },
  plugins: [],
};
export default config;
