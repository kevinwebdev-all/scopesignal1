# ScopeSignal

**Protect your work. Price every change.**

ScopeSignal helps independent professionals compare new client requests with an original project agreement. It labels each requested task as included, out of scope, or unclear, shows supporting agreement evidence, estimates additional work, and drafts a client-ready change request.

## Features
- Create and save project agreements in the browser.
- Extract deliverables, exclusions, revision limits, deadlines, and ambiguities with Gemini.
- Analyze new client requests against the saved agreement.
- Show evidence excerpts and conservative classifications.
- Estimate additional work using hours × hourly rate.
- Generate an editable change-request message.
- Keep an analysis history in browser local storage.
- Includes a sample project for a quick demonstration.

## Requirements
- Node.js 20.9 or newer.
- A Gemini API key from https://aistudio.google.com/apikey.

## Run locally
1. Install dependencies: `npm install`
2. Copy `.env.example` to `.env.local`.
3. Add your key to `GEMINI_API_KEY` in `.env.local`.
4. Run `npm run dev`.
5. Open http://localhost:3000.

## Deploy to Vercel
Import this repository into Vercel. Add `GEMINI_API_KEY` and optionally `GEMINI_MODEL` in Project Settings → Environment Variables, then deploy. Never commit `.env.local` or expose the key in browser code.

## Privacy and limitations
The MVP stores projects and analyses in the current browser's local storage. Clearing browser data removes that information. Do not paste confidential client agreements unless you have permission to process them with the configured AI provider. AI classifications are decision support, not legal advice. The app intentionally marks weakly supported conclusions as **Unclear**.

## Scripts
- `npm run dev` — development server
- `npm run build` — production build
- `npm run start` — production server
- `npm run lint` — ESLint
- `npm run typecheck` — TypeScript check
