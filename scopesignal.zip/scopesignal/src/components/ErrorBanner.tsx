export function ErrorBanner({ message, onClose }: { message: string; onClose?: () => void }) {
  return <div role="alert" className="flex items-start justify-between gap-3 rounded-xl border border-rose-400/25 bg-rose-400/10 px-4 py-3 text-sm text-rose-200"><span>{message}</span>{onClose && <button onClick={onClose} aria-label="Dismiss error" className="text-rose-100">✕</button>}</div>;
}
