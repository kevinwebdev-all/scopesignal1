import Link from "next/link";

export function Header() {
  return <header className="sticky top-0 z-20 border-b border-white/10 bg-ink/90 backdrop-blur-xl"><div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4"><Link href="/" className="flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-xl bg-gold text-lg font-black text-ink">S</span><span className="text-lg font-semibold tracking-tight">Scope<span className="text-gold">Signal</span></span></Link><nav className="flex items-center gap-5 text-sm text-muted"><Link className="transition hover:text-white" href="/">Dashboard</Link><Link className="transition hover:text-white" href="/analyses">History</Link><a className="hidden transition hover:text-white sm:inline" href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">Gemini API</a></nav></div></header>;
}
