import Link from "next/link";
export function EmptyState({ title = "Nothing here yet", description = "Create your first project to start protecting your work." }: { title?: string; description?: string }) {
  return <div className="rounded-2xl border border-dashed border-white/15 bg-white/[0.02] px-6 py-14 text-center"><div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-gold/10 text-2xl text-gold">✳</div><h3 className="text-lg font-semibold">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted">{description}</p><Link href="/#new-project" className="mt-5 inline-flex rounded-xl bg-gold px-4 py-2.5 text-sm font-semibold text-ink transition hover:bg-amber-300">Create a project</Link></div>;
}
