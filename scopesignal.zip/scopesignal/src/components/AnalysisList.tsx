import Link from "next/link";
import type { ScopeAnalysis } from "@/lib/analysis-types";
export function AnalysisList({ analyses }: { analyses: ScopeAnalysis[] }) {
  return <div className="space-y-2">{analyses.map((item) => { const outside = item.findings.filter((f) => f.classification === "OUT_OF_SCOPE").length; return <Link key={item.id} href={`/analyses/${item.id}`} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/10 bg-white/[0.025] p-4 transition hover:border-gold/40"><div><p className="font-medium">{item.projectName}</p><p className="mt-1 text-xs text-muted">{item.clientName} · {new Date(item.createdAt).toLocaleDateString()}</p></div><div className="text-right"><p className="text-sm text-gold">{outside} out-of-scope</p><p className="mt-1 text-xs text-muted">{item.findings.length} findings</p></div></Link>; })}</div>;
}
