"use client";
export function DeleteAnalysisButton({ onDelete }: { onDelete: () => void }) {
  return <button onClick={() => { if (window.confirm("Delete this analysis?")) onDelete(); }} className="rounded-lg border border-rose-400/20 px-3 py-2 text-xs text-rose-300 hover:bg-rose-400/10">Delete analysis</button>;
}
