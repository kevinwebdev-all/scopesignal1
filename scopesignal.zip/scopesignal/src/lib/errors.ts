export class AppError extends Error {
  constructor(message: string, public status = 400) { super(message); this.name = "AppError"; }
}
export function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Something went wrong. Please try again.";
}
