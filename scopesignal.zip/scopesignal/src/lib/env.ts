export function getGeminiConfig() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("Gemini is not configured. Add GEMINI_API_KEY to your server environment variables.");
  return { apiKey, model: process.env.GEMINI_MODEL || "gemini-2.5-flash" };
}
