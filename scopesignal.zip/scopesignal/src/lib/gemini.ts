import { getGeminiConfig } from "@/lib/env";
import { AnalyzeResponseSchema, type ValidatedAnalyzeResponse } from "@/lib/schemas";
import { AppError } from "@/lib/errors";

export async function analyzeWithGemini(prompt: string): Promise<ValidatedAnalyzeResponse> {
  const { apiKey, model } = getGeminiConfig();
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  let response: Response;
  try {
    response = await fetch(endpoint, {
      method: "POST", headers: { "Content-Type": "application/json" }, cache: "no-store",
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { responseMimeType: "application/json", temperature: 0.2, maxOutputTokens: 5000 },
      }),
      signal: AbortSignal.timeout(45_000),
    });
  } catch { throw new AppError("Could not reach Gemini. Check your connection and try again.", 502); }
  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    console.error("Gemini API error", response.status, detail.slice(0, 500));
    if (response.status === 400 || response.status === 404) throw new AppError("Gemini rejected this request or model. Check GEMINI_MODEL and try again.", 502);
    if (response.status === 429) throw new AppError("Gemini rate limit reached. Wait a little and try again.", 429);
    throw new AppError("Gemini could not complete the analysis. Please try again later.", 502);
  }
  const payload = await response.json() as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
  const text = payload.candidates?.[0]?.content?.parts?.map((part) => part.text || "").join("").trim();
  if (!text) throw new AppError("Gemini returned an empty response. Please try again.", 502);
  let parsed: unknown;
  try { parsed = JSON.parse(text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "")); }
  catch { throw new AppError("Gemini returned invalid structured data. Please retry.", 502); }
  const result = AnalyzeResponseSchema.safeParse(parsed);
  if (!result.success) { console.error("Gemini schema validation failed", result.error.flatten()); throw new AppError("Gemini's response did not pass validation. Please retry.", 502); }
  return result.data;
}
