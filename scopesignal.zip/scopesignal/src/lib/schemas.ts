import { z } from "zod";

export const AnalyzeRequestSchema = z.object({
  agreement: z.string().trim().min(30, "Please provide the original agreement (at least 30 characters).").max(20000),
  request: z.string().trim().min(5, "Please describe the client's new request.").max(10000),
});

const stringList = z.array(z.string().trim().min(1).max(1000)).max(30);
export const AgreementSummarySchema = z.object({
  included: stringList, excluded: stringList, revisionLimits: stringList, deadlines: stringList, unclearTerms: stringList,
});
export const FindingSchema = z.object({
  task: z.string().trim().min(1).max(1000),
  classification: z.enum(["INCLUDED", "OUT_OF_SCOPE", "UNCLEAR"]),
  reasoning: z.string().trim().min(1).max(2000),
  evidence: z.string().max(2000),
  estimatedHours: z.number().min(0).max(1000),
});
export const AnalyzeResponseSchema = z.object({
  agreementSummary: AgreementSummarySchema,
  findings: z.array(FindingSchema).min(1).max(30),
  summary: z.string().trim().min(1).max(3000),
});
export type ValidatedAnalyzeResponse = z.infer<typeof AnalyzeResponseSchema>;
