const WINDOW_MS = 60_000;
const MAX_REQUESTS = 12;
const requests = new Map<string, number[]>();

export function checkRateLimit(key: string): boolean {
  const now = Date.now();
  const recent = (requests.get(key) || []).filter((time) => now - time < WINDOW_MS);
  if (recent.length >= MAX_REQUESTS) { requests.set(key, recent); return false; }
  recent.push(now); requests.set(key, recent);
  if (requests.size > 1000) {
    for (const [storedKey, times] of requests) if (!times.some((time) => now - time < WINDOW_MS)) requests.delete(storedKey);
  }
  return true;
}
