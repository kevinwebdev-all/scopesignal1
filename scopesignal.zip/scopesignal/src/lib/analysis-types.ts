export type Classification = "INCLUDED" | "OUT_OF_SCOPE" | "UNCLEAR";

export interface Project {
  id: string; name: string; clientName: string; agreement: string; contractValue: number; hourlyRate: number; createdAt: string; updatedAt: string;
}
export interface AgreementSummary {
  included: string[]; excluded: string[]; revisionLimits: string[]; deadlines: string[]; unclearTerms: string[];
}
export interface RequestFinding {
  task: string; classification: Classification; reasoning: string; evidence: string; estimatedHours: number;
}
export interface ScopeAnalysis {
  id: string; projectId: string; projectName: string; clientName: string; request: string; findings: RequestFinding[];
  summary: string; createdAt: string; additionalHours: number; hourlyRate: number; changeMessage: string;
}
export interface AnalyzeResponse { agreementSummary: AgreementSummary; findings: RequestFinding[]; summary: string; }
