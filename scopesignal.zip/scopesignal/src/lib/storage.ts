import type { Project, ScopeAnalysis } from "@/lib/analysis-types";

const PROJECTS_KEY = "scopesignal.projects.v1";
const ANALYSES_KEY = "scopesignal.analyses.v1";
function read<T>(key: string): T[] {
  if (typeof window === "undefined") return [];
  try { const value: unknown = JSON.parse(window.localStorage.getItem(key) || "[]"); return Array.isArray(value) ? value as T[] : []; }
  catch { return []; }
}
function write<T>(key: string, value: T[]): void {
  if (typeof window !== "undefined") window.localStorage.setItem(key, JSON.stringify(value));
}
export const storage = {
  getProjects: () => read<Project>(PROJECTS_KEY),
  saveProject: (project: Project) => { const items = read<Project>(PROJECTS_KEY); write(PROJECTS_KEY, [project, ...items.filter((item) => item.id !== project.id)]); },
  deleteProject: (id: string) => { write(PROJECTS_KEY, read<Project>(PROJECTS_KEY).filter((item) => item.id !== id)); write(ANALYSES_KEY, read<ScopeAnalysis>(ANALYSES_KEY).filter((item) => item.projectId !== id)); },
  getAnalyses: () => read<ScopeAnalysis>(ANALYSES_KEY),
  saveAnalysis: (analysis: ScopeAnalysis) => { const items = read<ScopeAnalysis>(ANALYSES_KEY); write(ANALYSES_KEY, [analysis, ...items.filter((item) => item.id !== analysis.id)]); },
  deleteAnalysis: (id: string) => write(ANALYSES_KEY, read<ScopeAnalysis>(ANALYSES_KEY).filter((item) => item.id !== id)),
};
