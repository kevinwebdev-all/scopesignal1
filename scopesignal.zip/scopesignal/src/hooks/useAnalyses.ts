"use client";

import { useCallback, useEffect, useState } from "react";
import type { Project, ScopeAnalysis } from "@/lib/analysis-types";
import { storage } from "@/lib/storage";

export function useAnalyses() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [analyses, setAnalyses] = useState<ScopeAnalysis[]>([]);
  const [ready, setReady] = useState(false);
  const refresh = useCallback(() => { setProjects(storage.getProjects()); setAnalyses(storage.getAnalyses()); }, []);
  useEffect(() => { refresh(); setReady(true); }, [refresh]);
  const saveProject = useCallback((project: Project) => { storage.saveProject(project); refresh(); }, [refresh]);
  const saveAnalysis = useCallback((analysis: ScopeAnalysis) => { storage.saveAnalysis(analysis); refresh(); }, [refresh]);
  const deleteProject = useCallback((id: string) => { storage.deleteProject(id); refresh(); }, [refresh]);
  const deleteAnalysis = useCallback((id: string) => { storage.deleteAnalysis(id); refresh(); }, [refresh]);
  return { projects, analyses, ready, refresh, saveProject, saveAnalysis, deleteProject, deleteAnalysis };
}
