import { NextRequest, NextResponse } from "next/server";
import { AnalyzeRequestSchema } from "@/lib/schemas";
import { analyzeWithGemini } from "@/lib/gemini";
import { buildAnalysisPrompt } from "@/lib/prompts";
import { AppError, errorMessage } from "@/lib/errors";
import { checkRateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const maxDuration = 60;
export async function POST(request: NextRequest) {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anonymous";
  if (!checkRateLimit(forwarded)) return NextResponse.json({ error: "Too many analyses. Please wait one minute and try again." }, { status: 429 });
  try {
    const body: unknown = await request.json();
    const input = AnalyzeRequestSchema.safeParse(body);
    if (!input.success) return NextResponse.json({ error: input.error.issues[0]?.message || "Invalid input." }, { status: 400 });
    const result = await analyzeWithGemini(buildAnalysisPrompt(input.data.agreement, input.data.request));
    return NextResponse.json(result, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    const status = error instanceof AppError ? error.status : 500;
    if (!(error instanceof AppError)) console.error("ScopeSignal analysis error", error);
    return NextResponse.json({ error: errorMessage(error) }, { status });
  }
}
