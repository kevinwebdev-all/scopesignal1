import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Header } from "@/components/Header";

export const metadata: Metadata = { title: "ScopeSignal — Protect your work", description: "Compare client requests with your original agreement. Spot scope changes, estimate extra work and draft change requests." };
export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return <html lang="en"><body><Header />{children}<footer className="mx-auto mt-16 max-w-7xl border-t border-white/10 px-5 py-7 text-center text-xs text-muted">ScopeSignal · Protect your work. Price every change. <span className="mx-1">·</span> AI-assisted decision support, not legal advice.</footer></body></html>;
}
