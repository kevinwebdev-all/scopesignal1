"use client";
import Link from "next/link";
import { useAnalyses } from "@/hooks/useAnalyses";
import { AnalysisList } from "@/components/AnalysisList";
import { EmptyState } from "@/components/EmptyState";
export default function AnalysesPage() { const { analyses, ready } = useAnalyses(); return <main className="mx-auto max-w-5xl px-5 py-10"><Link href="/" className="text-sm text-gold hover:underline">← Dashboard</Link><div className="mb-7 mt-5"><p className="text-xs font-semibold uppercase tracking-[.2em] text-gold">Your workspace</p><h1 className="mt-2 text-3xl font-semibold">Analysis history</h1><p className="mt-2 text-sm text-muted">Review previous client requests and scope decisions saved in this browser.</p></div>{!ready ? <p className="text-sm text-muted">Loading...</p> : analyses.length ? <AnalysisList analyses={analyses}/> : <EmptyState title="No saved analyses"/>}</main>; }
